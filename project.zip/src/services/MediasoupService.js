process.env.DEBUG = "mediasoup*"
const mediasoup = require('mediasoup');
const config = require('../config');

class MediasoupService {
  constructor() {
    this.worker = null;
    this.router = null;
    this.transports = new Map();
    this.producers = new Map();
    this.consumers = new Map();
  }

  async initialize() {
    console.log(' Initializing mediasoup worker...');
    try {
      this.worker = await mediasoup.createWorker(config.mediasoup.worker);

      console.log(' Mediasoup worker created');

      this.router = await this.worker.createRouter({ mediaCodecs: config.mediasoup.router.mediaCodecs });
      console.log(' Mediasoup router created');

      this.worker.on('died', () => {
        console.error(' Mediasoup worker died, exiting in 2 seconds...');
        setTimeout(() => process.exit(1), 2000);
      });
    } catch (error) {
      console.error(' Error initializing mediasoup:', error);
      throw error;
    }
  }

  async createWebRtcTransport() {
    try {
      const transport = await this.router.createWebRtcTransport(config.mediasoup.webRtcTransport);

      // Store the transport immediately after creation
      this.transports.set(transport.id, transport);

      console.log(' Created WebRTC transport:', {
        id: transport.id,
        iceParameters: transport.iceParameters,
        iceCandidates: transport.iceCandidates.length,
        storedTransports: this.transports.size // Log the number of stored transports
      });

      transport.on('dtlsstatechange', (dtlsState) => {
        console.log(' Transport DTLS state changed:', {
          transportId: transport.id,
          state: dtlsState
        });
      });

      transport.on('close', () => {
        console.log(' Transport closed:', {
          transportId: transport.id
        });
        // Remove the transport from the map when it's closed
        this.transports.delete(transport.id);
      });

      const transportInfo = {
        id: transport.id,
        iceParameters: transport.iceParameters,
        iceCandidates: transport.iceCandidates,
        dtlsParameters: transport.dtlsParameters,
      };

      console.log(' Returning transport info:', transportInfo);
      return transportInfo;
    } catch (error) {
      console.error(' Error creating WebRTC transport:', error);
      throw error;
    }
  }

  async connectTransport(transportId, dtlsParameters) {
    if (!this.transports.has(transportId)) {
      throw new Error(`Transport with id ${transportId} not found`);
    }

    const transport = this.transports.get(transportId);
    await transport.connect({ dtlsParameters });
    console.log(' Transport connected:', {
      transportId: transportId,
    });
    return true;
  }

  async createProducer(transportId, kind, rtpParameters) {
    try {
      const transport = this.transports.get(transportId);
      if (!transport) {
        throw new Error(`Transport not found: ${transportId}`);
      }

      console.log('Creating producer with:', {
        transportId,
        kind,
        rtpParameters
      });

      const producer = await transport.produce({ kind, rtpParameters });
      console.log('✅ Created producer:', {
        transportId: transportId,
        producerId: producer.id,
        kind: kind
      });

      this.producers.set(producer.id, producer);

      producer.on('score', (score) => {
        console.log('📊 Producer score updated:', {
          producerId: producer.id,
          score: score
        });
      });

      // Add log to track data coming from the producer
      producer.on('rtp', (rtpPacket) => {
        console.log('📨 Received RTP packet from producer:', {
          producerId: producer.id,
          rtpPacket: rtpPacket, // You can inspect the rtpPacket for details
        });
      });
      
      return producer;
    } catch (error) {
      console.error('❌ Error creating producer:', error);
      throw error;
    }
  }

  async createConsumer(transportId, producerId, rtpCapabilities) {
    try {
      const transport = this.transports.get(transportId);
      if (!transport) {
        throw new Error(`Transport not found: ${transportId}`);
      }

      const producer = this.producers.get(producerId);
      if (!producer) {
        throw new Error(`Producer not found: ${producerId}`);
      }

      if (!this.router.canConsume({ producerId, rtpCapabilities })) {
        throw new Error('Cannot consume this producer');
      }

      const consumer = await transport.consume({
        producerId,
        rtpCapabilities,
        paused: true,
      });

      console.log(' Created consumer:', {
        transportId: transportId,
        consumerId: consumer.id,
        producerId: producerId,
        kind: consumer.kind
      });

      this.consumers.set(consumer.id, consumer);

      consumer.on('score', (score) => {
        console.log(' Consumer score updated:', {
          consumerId: consumer.id,
          score: score
        });
      });

      return {
        id: consumer.id,
        producerId: consumer.producerId,
        kind: consumer.kind,
        rtpParameters: consumer.rtpParameters,
      };
    } catch (error) {
      console.error(' Error creating consumer:', error);
      throw error;
    }
  }

  getRtpCapabilities() {
    return this.router.rtpCapabilities;
  }

  async closeTransport(transportId) {
    try {
      const transport = this.transports.get(transportId);
      if (transport) {
        console.log(' Closing transport:', {
          transportId: transportId
        });
        await transport.close();
        this.transports.delete(transportId);
        console.log(' Transport closed successfully:', {
          transportId: transportId
        });
      }
    } catch (error) {
      console.error(' Error closing transport:', error);
      throw error;
    }
  }

  getTransport(transportId) {
    return this.transports.get(transportId);
  }

  getTransportStats(transportId) {
    const transport = this.transports.get(transportId);
    if (!transport) {
      throw new Error(`Transport not found: ${transportId}`);
    }
    return transport.getStats();
  }
}

module.exports = new MediasoupService();
