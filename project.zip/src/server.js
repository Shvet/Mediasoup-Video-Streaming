require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mediasoupService = require('./services/MediasoupService');
const handleConnection = require('./handlers/socketHandlers');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

async function startServer() {
  try {
    await mediasoupService.initialize();
    
    io.on('connection', (socket) => {
      console.log('a user connected');
      handleConnection(socket, io);
    });

    const port = process.env.PORT || 3000;
    server.listen(port,'0.0.0.0', () => {
      console.log(`Server is running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();